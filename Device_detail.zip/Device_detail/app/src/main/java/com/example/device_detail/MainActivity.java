package com.example.device_detail;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;

import java.io.File;
import java.text.DecimalFormat;

import android.app.ActivityManager;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Camera;
import android.graphics.ImageFormat;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.opengl.GLES20;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.util.Size;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    Button btn_info;
    TextView text_view, txt_manufature, txt_serial, txt_ram, txt_storage,txt_Gyroscope, txt_Barometer, txt_Accelerometer, txt_Rotation_Vector,txt_Proximity,txt_Ambient_light_sensor, gpu_info,txt_free_storage, battery, android_version,back_cam,camera_apreture,processor_cpu;
    private SensorManager sensorManager;
    private Sensor gyroSensor, barometerSensor, accelSensor, rotationSensor, proximitySensor, lightSensor;

    @Override
    protected void onCreate ( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );




        // Get the SensorManager instance
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        // Get references to the sensors you want to use

        gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        barometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
        accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);


         txt_Gyroscope=findViewById ( R.id.TextView15 );
        btn_info = findViewById ( R.id.button );
        text_view = findViewById ( R.id.TextView );
        txt_manufature = findViewById ( R.id.TextView1 );
        txt_serial = findViewById ( R.id.TextView5 );
        txt_ram = findViewById ( R.id.TextView2 );
        txt_storage = findViewById ( R.id.TextView3 );
        battery = findViewById ( R.id.TextView7 );
        android_version = findViewById ( R.id.TextView8 );
        back_cam=findViewById ( R.id.TextView10 );
        gpu_info=findViewById ( R.id.TextView14 );
        txt_Rotation_Vector=findViewById ( R.id.TextView16 );
        txt_Accelerometer=findViewById ( R.id.TextView18 );
//        camera_apreture=findViewById ( R.id.TextView12 );
        processor_cpu=findViewById ( R.id.TextView12 );
        txt_Proximity=findViewById ( R.id.TextView20 );
        txt_Ambient_light_sensor=findViewById ( R.id.TextView22 );

        // Create an instance of the IntentFilter
        IntentFilter ifilter = new IntentFilter ( Intent.ACTION_BATTERY_CHANGED );

// Use the registerReceiver method to register a BroadcastReceiver
        Intent batteryStatus = registerReceiver ( null , ifilter );

// Extract the battery level as an integer
        int level = batteryStatus.getIntExtra ( BatteryManager.EXTRA_LEVEL , -1 );

// Extract the battery scale as an integer
        int scale = batteryStatus.getIntExtra ( BatteryManager.EXTRA_SCALE , -1 );

// Calculate the battery percentage
        float batteryPct = level / (float) scale * 100;


//// Camera Camera Aperture code
//        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
//        String[] cameraIds = manager.getCameraIdList();
//
//// Choose the back camera and get its characteristics
//        CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraIds[0]);
//
//// Get the camera aperture
//        float aperture = characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)[0];


        // Camera Action for Back
        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        String[] cameraIds = new String[0];
        try {
            cameraIds = manager.getCameraIdList();
        } catch (CameraAccessException e) {
            throw new RuntimeException ( e );
        }

// Choose the back camera and get its characteristics
        CameraCharacteristics characteristics = null, cam = null;
        try {
            characteristics = manager.getCameraCharacteristics(cameraIds[0]);

        } catch (CameraAccessException e) {
            throw new RuntimeException ( e );
        }
        StreamConfigurationMap configs = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);

// Get the largest supported size for capturing still images
        Size[] sizes = configs.getOutputSizes( ImageFormat.JPEG);
        Size largestSize = sizes[0];
        for (Size size : sizes) {
            if ((size.getWidth() * size.getHeight()) > (largestSize.getWidth() * largestSize.getHeight())) {
                largestSize = size;
            }
        }

// Calculate megapixels
        double megapixels = (largestSize.getWidth() * largestSize.getHeight()) / 1000000.0;

//        float aperture = characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)[0];


        btn_info.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick ( View v ) {
                String SERIAL = (Build.SERIAL);
                String MODEL = (Build.MODEL);
                String str_ram = getMemorySizeHumanized ();
                 String cpu =getProcessorInfo();
                 String gpu=getGPUInfo();
                double disk_store = getTotalDiskSpace ();
                //String store= String.valueOf ( disk_store );
                String rounded = String.format ( "%.0f" , disk_store );
//                String ID = ("ID: " + Build.MODEL);
               String Manufacture = (Build.MODEL);
                String androidVersion = Build.VERSION.RELEASE;
//                String brand = ("Brand: " + Build.BRAND);
//                String type = ("type:" + Build.TYPE);
//                String user = ("MODEL:" + Build.USER);
//                String MODEL = ("MODEL:" + Build.MODEL);
//                String MODEL = ("MODEL:" + Build.MODEL);
//                String MODEL = ("MODEL:" + Build.MODEL);
//                String MODEL = ("MODEL:" + Build.MODEL);


                text_view.setText ( MODEL );
              txt_manufature.setText ( Manufacture );
               // txt_manufature.setText ( imeiNumber);
                txt_storage.setText ( rounded + " GB" );
                txt_ram.setText ( str_ram );
                txt_serial.setText ( SERIAL );
                battery.setText ( String.valueOf ( batteryPct ) + " %" );
                android_version.setText ( androidVersion );
                back_cam.setText (   String.valueOf (megapixels)+" MP" );
                processor_cpu.setText ( cpu );
                gpu_info.setText ( gpu );

//                camera_apreture.setText (  String.valueOf (aperture) );

            }
        } );



    }

    // method for getting Ram Size.
    public String getMemorySizeHumanized () {
        Context context = getApplicationContext ();

        ActivityManager activityManager = (ActivityManager) context.getSystemService ( Context.ACTIVITY_SERVICE );

        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo ();

        activityManager.getMemoryInfo ( memoryInfo );

        DecimalFormat twoDecimalForm = new DecimalFormat ( "#.##" );

        String finalValue = "";
        long totalMemory = memoryInfo.totalMem;

        double kb = totalMemory / 1024.0;
        double mb = totalMemory / 1048576.0;
        double gb = totalMemory / 1073741824.0;
        double tb = totalMemory / 1099511627776.0;

        if (tb > 1) {
            finalValue = twoDecimalForm.format ( tb ).concat ( " TB" );
        } else if (gb > 1) {
            finalValue = twoDecimalForm.format ( gb ).concat ( " GB" );
        } else if (mb > 1) {
            finalValue = twoDecimalForm.format ( mb ).concat ( " MB" );
        } else if (kb > 1) {
            finalValue = twoDecimalForm.format ( mb ).concat ( " KB" );
        } else {
            finalValue = twoDecimalForm.format ( totalMemory ).concat ( " Bytes" );
        }

        return finalValue;
    }

    public static double getTotalDiskSpace () {
        File path = Environment.getExternalStorageDirectory (); // or any other path to the storage device
        long totalSpace = path.getTotalSpace ();
        long freeSpace = path.getUsableSpace ();
        double totalSpaceGB = (double) totalSpace / (1024 * 1024 * 1024);
        double freeSpaceGB = (double) freeSpace / (1024 * 1024 * 1024);
        double usedSpaceGB = totalSpaceGB - freeSpaceGB;
        Log.d ( "Disk Space" , "Total: " + totalSpaceGB + " GB, Used: " + usedSpaceGB + " GB, Free: " + freeSpaceGB + " GB" );
        return totalSpaceGB;
    }

    public static double getTotalfreeDiskSpace () {
        File path = Environment.getExternalStorageDirectory (); // or any other path to the storage device
        long totalSpace = path.getTotalSpace ();
        long freeSpace = path.getUsableSpace ();
        double freeSpaceGB = (double) freeSpace / (1024 * 1024 * 1024);
        return freeSpaceGB;
    }
// for CPU information method
        public static String getProcessorInfo() {
            String processorInfo = "Unknown";
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                processorInfo = Build.SUPPORTED_ABIS[0];
            } else {
                processorInfo = Build.CPU_ABI;
            }
            return processorInfo;
        }
/// For GPU information method
public static String getGPUInfo() {
    String gpuInfo = "Unknown";
    if(GLES20.glGetString(GLES20.GL_RENDERER) != null) {
        gpuInfo = GLES20.glGetString(GLES20.GL_RENDERER);
    }
    return gpuInfo;
}
//In the above code, we use the glGetString() method from android.opengl.GLES20 to get
// the name of the GPU renderer. If the method returns a non-null String, we assume that the GPU information
// is available and return it. Otherwise, we return "Unknown".

//    @Override
//    public void onSensorChanged ( SensorEvent event ) {
//
//    }

    @Override
    public void onAccuracyChanged ( Sensor sensor , int accuracy ) {

    }


    @Override
    protected void onResume() {
        super.onResume();

        // Register the sensor listeners
       // sensorManager.registerListener(this, gpsSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, gyroSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, barometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Unregister the sensor listeners to save battery
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Get the sensor type and sensor values
        int sensorType = event.sensor.getType ();
        float[] values = event.values;

        // Process the sensor data based on sensor type
        switch (sensorType) {
//            case Sensor.TYPE_LOCATION:
//                // Process GPS sensor data
//                double latitude = values[0];
//                double longitude = values[1];
//                double altitude = values[2];
//                // Do something with the data...
//                break;
            case Sensor.TYPE_GYROSCOPE:
                // Process gyroscope sensor data
                float x = values[0];
                float y = values[1];
                float z = values[2];
                // Do something with the data...
                txt_Gyroscope.setText ( x+" "+y+" "+z );
                break;
            case Sensor.TYPE_PRESSURE:
                // Process barometer sensor data
                float pressure = values[0];
                //txt_Barometer.setText(String.valueOf( pressure ));
                // Do something with the data...
                break;
            case Sensor.TYPE_ACCELEROMETER:
                // Process accelerometer sensor data
                float ax = values[0];
                float ay = values[1];
                float az = values[2];
                txt_Accelerometer.setText (  ax+" "+ay+" "+az  );
                // Do something with the data...
                break;
            case Sensor.TYPE_ROTATION_VECTOR:
                // Process rotation vector sensor data
                float[] rotationMatrix = new float[9];
                SensorManager.getRotationMatrixFromVector ( rotationMatrix , values );
                txt_Rotation_Vector.setText ( String.valueOf(rotationMatrix  ));
                // Do something with the data...
                break;
            case Sensor.TYPE_PROXIMITY:
                // Process proximity sensor data
                float distance = values[0];
                txt_Proximity.setText (String.valueOf ( distance) );
                // Do something with the data...
                break;
            case Sensor.TYPE_LIGHT:
                // Process ambient light sensor data
                float light = values[0];
                txt_Ambient_light_sensor.setText (String.valueOf( light) );
                // Do something with the data...
                break;
        }
    }

}